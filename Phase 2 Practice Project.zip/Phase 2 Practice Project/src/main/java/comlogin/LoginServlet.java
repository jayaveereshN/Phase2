package comlogin;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Hardcoded valid credentials (for demonstration purposes)
        String validUsername = "user";
        String validPassword = "password";

        // Retrieve user-entered credentials from the form
        String enteredUsername = request.getParameter("username");
        String enteredPassword = request.getParameter("password");

        // Check if entered credentials are valid
        boolean isValid = validUsername.equals(enteredUsername) && validPassword.equals(enteredPassword);

        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            out.println("<html>");
            out.println("<head><title>Login Result</title></head>");
            out.println("<body>");

            if (isValid) {
                out.println("<h2>Login Successful!</h2>");
            } else {
                out.println("<h2>Login Failed. Invalid username or password.</h2>");
            }

            out.println("</body>");
            out.println("</html>");
        }
    }
}

